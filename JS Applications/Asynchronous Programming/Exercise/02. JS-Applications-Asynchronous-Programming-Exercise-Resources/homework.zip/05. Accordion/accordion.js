async function solution() {
    const [data, extra] = await Promise.all([
        getData(),
        getExtra()
    ]);

    loadData(data, extra);

    document.getElementById('main').addEventListener('click', (event) => {
        const btn = event.target;
        if (btn.tagName === 'BUTTON') {
            toggle(btn);
        }
    });
}

function toggle(btn) {
    const accordion = btn.parentNode.parentNode;
    const extra = accordion.children[1];

    extra.style.display = extra.style.display === 'block' ? 'none' : 'block';
    btn.textContent = btn.textContent === 'More' ? 'Less' : 'More';
}

solution();

async function loadData(data, extra) {
    const main = document.getElementById('main');
    data.forEach(d => {
        const accordion = e('div', {className: 'accordion'}, [
            e('div', {className: 'head'}, [
                e('span', {}, d.title),
                e('button', {id: d._id, className: 'button'}, 'More')
            ]),
            e('div', {className: 'extra'}, e('p', {}, extra[d._id].content))
        ]);
        main.appendChild(accordion);
    });
}

async function getExtra() {
    const url = 'http://localhost:3030/jsonstore/advanced/articles/details/';
    const response = await fetch(url);
    const data = await response.json();

    return data;
}

async function getData() {
    const url = 'http://localhost:3030/jsonstore/advanced/articles/list';
    const response = await fetch(url);
    const data = await response.json();

    return data;
}

function e(type, attributes, ...content) {
    const result = document.createElement(type);

    for (let [attr, value] of Object.entries(attributes || {})) {
        if (attr.substring(0, 2) === 'on') {
            result.addEventListener(attr.substring(2).toLocaleLowerCase(), value);
        } else {
            result[attr] = value;
        }
    }

    content = content.reduce((a, c) => a.concat(Array.isArray(c) ? c : [c]), []);

    content.forEach(e => {
        if (typeof e == 'string' || typeof e == 'number') {
            const node = document.createTextNode(e);
            result.appendChild(node);
        } else {
            result.appendChild(e);
        }
    });

    return result;
}